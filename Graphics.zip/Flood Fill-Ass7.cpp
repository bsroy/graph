#include<iostream>
#include<graphics.h>
#include<stdlib.h>
#include<math.h>
using namespace std;
class flood
{
public:
void floodFill(int x, int y, int old, int fill)
{
	int current;
	current=getpixel(x,y);
	if(current==old)
	{
		putpixel(x,y,fill);
		delay(5);
		floodFill(x+1,y,old,fill);
		floodFill(x-1,y,old,fill);
		floodFill(x, y+1,old,fill);
		floodFill(x,y-1,old,fill);
	}
}
};
int main()
{	
		flood f;
		int x,y,o=0;
		
		int gDriver=DETECT,gmode;
		initgraph(&gDriver,&gmode,NULL);
		cout<<"Enter the co-ordinates of rectangle";

		rectangle(100,100,300,300);
		x=(100+300)/2;
		y=(100+300)/2;
		f.floodFill(x,y,o,4);
		
		closegraph();
		return 0;
	delay(10000);
}
