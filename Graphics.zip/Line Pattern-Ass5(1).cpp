#include<iostream>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>
using namespace std;
class pattern
{
  private : int x[100],y[100],n;

  public : void accept();
	   void draw(int x[100],int y[100]);
	   

};

void pattern :: accept()
{
	int i,j;
	cout<<"Enter co-ordinate of rectangle in matrix form\n";
	for(i=0;i<4;i++)
	 {
		 cout<<"\nx["<<i<<"]= ";
		 cin>>x[i];
		 cout<<"y["<<i<<"]= ";
		 cin>>y[i];
	 }
	 draw(x,y);
}


			
void pattern:: draw(int x[100],int y[100])
{
 int i;
	//rectangle
 for(i=0;i<3;i++)
	{
		line(x[i],y[i],x[i+1],y[i+1]);
	}
	 line(x[i],y[i],x[0],y[0]);

	//rhombus

int p1,p2,q1,q2,r1,r2,s1,s2;
p1=(x[0]+x[1])/2;
p2=(y[0]+y[1])/2;

q1=(x[1]+x[2])/2;
q2=(y[1]+y[2])/2;

r1=(x[2]+x[3])/2;
r2=(y[2]+y[3])/2;

s1=(x[3]+x[0])/2;
s2=(y[3]+y[0])/2;

	line(p1,p2,q1,q2);
	line(q1,q2,r1,r2);
	line(r1,r2,s1,s2);
	line(s1,s2,p1,p2);
	
	//rectangle

	int a1,a2,b1,b2,c1,c2,d1,d2;
a1=(p1+q1)/2;
a2=(p2+q2)/2;

b1=(q1+r1)/2;
b2=(q2+r2)/2;

c1=(r1+s1)/2;
c2=(r2+s2)/2;

d1=(s1+p1)/2;
d2=(s2+p2)/2;

	line(a1,a2,b1,b2);
	line(b1,b2,c1,c2);
	line(c1,c2,d1,d2);
	line(d1,d2,a1,a2);
}


int main()
{
 char ch;
 int gd=DETECT,gm,i;
 int cho;
pattern t;

 do
  {
    initgraph(&gd,&gm,NULL);
    cleardevice();
     t.accept();
	       
   
     cout<<"\n\tDO U WANT CONTINUE (y/n) : ";
     cin>>ch;
   }while(ch=='y' || ch=='Y');
 return(0);
}
